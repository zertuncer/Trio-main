import LoopKitUI
import SwiftUI

struct ContinueButton: View {
    var text = String(localized: "Continue", comment: "Text for continue button")
    var loading: Binding<Bool> = .constant(false)
    var disabled: Binding<Bool> = .constant(false)
    let action: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            Button(action: action) {
                if loading.wrappedValue {
                    ActivityIndicator(isAnimating: .constant(true), style: .medium)
                } else {
                    Text(text)
                }
            }
            .buttonStyle(ActionButtonStyle())
            .padding([.bottom, .horizontal])
            .disabled(loading.wrappedValue || disabled.wrappedValue)
        }
        .padding(.vertical, 10)
    }
}

#Preview {
    ContinueButton(action: {})
}
