import HealthKit
import LoopKit
import LoopKitUI
import SwiftUI

enum PatchLifecycleState {
    case noPatch
    case active
    case activeLast24h
    case gracePeriod
    case expired
    case expiredBasalOnly
}

class MedtrumKitSettingsViewModel: PatchLifetimeFormatting, ObservableObject, PumpManagerStatusObserver {
    private let processQueue = DispatchQueue(label: "com.nightscout.medtrumkit.settingsViewModel")

    @Published var model: String = ""
    @Published var is300u: Bool = false
    @Published var showPumpTimeSyncWarning = false
    @Published var reservoirLevel: Double = 0
    @Published var maxReservoirLevel: Double = 1
    @Published var pumpTime = Date.distantPast
    @Published var pumpTimeSyncedAt = Date.distantPast
    @Published var patchState: PatchState = .none
    @Published var patchStateString: String = PatchState.none.description
    @Published var basalType: DoseType = .basal
    @Published var basalRate: String = ""
    @Published var tempBasalManual = false
    @Published var insulinType: InsulinType = .novolog
    @Published var lastSync = Date.distantPast
    @Published var hourlyLimit = 0
    @Published var dailyLimit = 0
    @Published var patchLifecycleProgress: Double = 0
    @Published var patchLifecycleState: PatchLifecycleState = .noPatch
    @Published var patchLifetime: String = ""
    @Published var patchActivatedAt: Date? = nil
    @Published var patchExpiresAt: Date? = nil
    @Published var patchGracePeriodFrom: Date? = nil
    @Published var patchGraceTimeout = ""
    @Published var isConnected: Bool = false
    @Published var isReconnecting: Bool = false
    @Published var isUpdatingPumpState = false
    @Published var isUpdatingSuspend = false
    @Published var isUpdatingTempBasal = false
    @Published var showingHeartbeatWarning = false
    @Published var showingDeleteConfirmation = false
    @Published var showingSuspendPicker = false
    @Published var hasPreviousPatch = false
    @Published var isClearingAlert = false
    
    @Published var useSilentTones = false {
        didSet {
            // prevent infinite loop: notifyStateDidChange() -> notify observers -> notify this view model -> set useSilentTones -> notifyStateDidChange() -> ...
            guard pumpManager?.state.useSilentTones != useSilentTones else {
                return
            }

            pumpManager?.state.useSilentTones = useSilentTones
            pumpManager?.notifyStateDidChange()
        }
    }

    public var pumpName: String {
        pumpManager?.state.pumpName ?? "Medtrum Nano"
    }

    let reservoirVolumeFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.roundingMode = .floor
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 0
        return formatter
    }()

    let basalRateFormatter: NumberFormatter = {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.minimumFractionDigits = 1
        numberFormatter.minimumIntegerDigits = 1
        return numberFormatter
    }()

    let dateFormatter = {
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        return formatter
    }()

    let dateTimeFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()

    let timeRemainingFormatter: DateComponentsFormatter = {
        let dateComponentsFormatter = DateComponentsFormatter()
        dateComponentsFormatter.allowedUnits = [.hour, .minute]
        dateComponentsFormatter.unitsStyle = .full
        dateComponentsFormatter.zeroFormattingBehavior = .dropAll
        return dateComponentsFormatter
    }()

    let deactivatePatchAction: () -> Void
    let pumpRemovalAction: () -> Void
    let toSettings: () -> Void
    let toTempBasal: () -> Void
    let toPatchDetails: () -> Void
    let toPreviousPatchDetails: () -> Void
    let toInsulinType: () -> Void
    let pumpActivationAction: (Bool) -> Void
    let activatePatchAction: () -> Void
    private let log = MedtrumLogger(category: "settingsViewModel")
    private let pumpManager: MedtrumPumpManager?
    init(
        _ pumpManager: MedtrumPumpManager?,
        _ deactivatePatchAction: @escaping () -> Void,
        _ pumpActivationAction: @escaping (Bool) -> Void,
        _ toSettings: @escaping () -> Void,
        _ toTempBasal: @escaping () -> Void,
        _ toPatchDetails: @escaping () -> Void,
        _ toPreviousPatchDetails: @escaping () -> Void,
        _ toInsulinType: @escaping () -> Void,
        _ pumpRemovalAction: @escaping () -> Void,
        _ activatePatchAction: @escaping () -> Void
    ) {
        self.pumpManager = pumpManager
        self.deactivatePatchAction = deactivatePatchAction
        self.pumpActivationAction = pumpActivationAction
        self.pumpRemovalAction = pumpRemovalAction
        self.toInsulinType = toInsulinType
        self.toPatchDetails = toPatchDetails
        self.toPreviousPatchDetails = toPreviousPatchDetails
        self.toSettings = toSettings
        self.toTempBasal = toTempBasal
        self.activatePatchAction = activatePatchAction
        super.init()

        guard let pumpManager = pumpManager else {
            return
        }

        isConnected = pumpManager.bluetooth.isConnected
        updateState(pumpManager.state)
        pumpManager.addStatusObserver(self, queue: processQueue)
    }

    deinit {
        pumpManager?.removeStatusObserver(self)
    }

    func reservoirText(for units: Double) -> String {
        reservoirVolumeFormatter.string(from: units as NSNumber) ?? ""
    }

    var tempBasalRemaining: String? {
        guard basalType == .tempBasal, let pumpManager else {
            return nil
        }

        let remaining = pumpManager.state.basalDose.estimatedEndDate.timeIntervalSinceNow
        let hours = Int(floor(remaining.hours))
        let minutes = Int(floor(remaining.minutes))

        if hours > 0 {
            return String(
                format: String(localized: "(%lld hr %lld min)", comment: "temp basal remaining hours+minutes"),
                hours,
                minutes - hours * 60
            )
        }

        return String(
            format: String(localized: "(%lld min)", comment: "temp basal remaining minutes"),
            minutes
        )
    }

    var patchLifecycleDays: Int? {
        guard patchLifecycleState == .active || patchLifecycleState == .activeLast24h, let patchGracePeriodFrom else {
            return nil
        }

        return Int((patchGracePeriodFrom.timeIntervalSince1970 - Date.now.timeIntervalSince1970).days.rounded(.towardZero))
    }

    var patchLifecycleHours: Int? {
        guard patchLifecycleState == .active || patchLifecycleState == .activeLast24h, let patchGracePeriodFrom else {
            return nil
        }

        return Int(
            (patchGracePeriodFrom.timeIntervalSince1970 - Date.now.timeIntervalSince1970).hours
                .truncatingRemainder(dividingBy: 24).rounded(.towardZero)
        )
    }

    var patchLifecycleMinutes: Int? {
        guard patchLifecycleState == .active || patchLifecycleState == .activeLast24h, let patchGracePeriodFrom else {
            return nil
        }

        return Int(
            (patchGracePeriodFrom.timeIntervalSince1970 - Date.now.timeIntervalSince1970).minutes
                .truncatingRemainder(dividingBy: 60).rounded(.towardZero)
        )
    }

    func syncData() {
        guard let pumpManager = self.pumpManager else {
            return
        }

        isUpdatingPumpState = true
        pumpManager.syncPumpData { _ in
            DispatchQueue.main.async {
                self.isUpdatingPumpState = false
            }
        }
    }

    func clearAlert(_ alertType: AlertType) {
        guard let pumpManager else {
            return
        }

        isClearingAlert = true
        pumpManager.clearAlert(alertType: alertType) { _ in
            DispatchQueue.main.async {
                self.isClearingAlert = false
            }
        }
    }

    func didChangeInsulinType(_ newType: InsulinType?) {
        guard let type = newType else {
            return
        }

        pumpManager?.state.insulinType = type
        pumpManager?.notifyStateDidChange()
        insulinType = type
    }

    func stopUsingMedtrum() {
        guard let pumpManager = self.pumpManager else {
            pumpRemovalAction()
            return
        }

        pumpManager.notifyDelegateOfDeactivation {
            DispatchQueue.main.async {
                self.pumpRemovalAction()
            }
        }
    }

    func getLogs() -> [URL] {
        if let pumpManager = self.pumpManager {
            log.info(pumpManager.state.debugDescription)
        }
        return log.getDebugLogs()
    }

    func toPumpActivation() {
        guard let pumpManager = self.pumpManager else {
            pumpActivationAction(false)
            return
        }

        let alreadyPrimed = pumpManager.state.pumpState.rawValue >= PatchState.primed.rawValue
        pumpActivationAction(alreadyPrimed)
    }

    func suspendDelivery(duration: TimeInterval) {
        guard let pumpManager else {
            return
        }

        pumpManager.suspendPatch(duration: duration) { error in
            DispatchQueue.main.async {
                self.isUpdatingSuspend = false
            }

            if let error = error {
                self.log.error("Failed to suspend delivery: \(error)")
            }
        }
    }

    func suspendResumeButtonPressed() {
        if basalType != .suspend {
            showingSuspendPicker = true
            return
        }

        guard let pumpManager = self.pumpManager else {
            return
        }

        isUpdatingSuspend = true
        pumpManager.resumeDelivery { error in
            DispatchQueue.main.async {
                self.isUpdatingSuspend = false
            }

            if let error = error {
                self.log.error("Failed to resume delivery: \(error)")
            }
        }
    }

    func stopTempBasal() {
        guard let pumpManager = self.pumpManager else {
            return
        }

        isUpdatingTempBasal = true
        pumpManager.enactTempBasal(unitsPerHour: 0, for: 0) { error in
            DispatchQueue.main.async {
                self.isUpdatingTempBasal = false
            }

            if let error = error {
                self.log.error("Failed to stop temp basal: \(error)")
            }
        }
    }

    func checkConnection() {
        guard let pumpManager = self.pumpManager else {
            return
        }

        if !pumpManager.bluetooth.isConnected {
            // Reconnect to patch
            isReconnecting = true
            pumpManager.bluetooth.ensureConnected { _ in
                DispatchQueue.main.async {
                    self.isReconnecting = false
                }
            }
            return
        } else {
            // Disconnect from patch
            pumpManager.bluetooth.disconnect(force: true)
            return
        }
    }

    func syncPumpTime() {
        guard let pumpManager = pumpManager else {
            return
        }

        isUpdatingPumpState = true
        pumpManager.bluetooth.ensureConnected { error in
            if error != nil {
                DispatchQueue.main.async {
                    self.isUpdatingPumpState = false
                }
                return
            }

            StateSyncer.syncTime(pumpManager: pumpManager)
            DispatchQueue.main.async {
                self.isUpdatingPumpState = false
            }
        }
    }
}

extension MedtrumKitSettingsViewModel {
    func pumpManager(
        _ pumpManager: any LoopKit.PumpManager,
        didUpdate _: LoopKit.PumpManagerStatus,
        oldStatus _: LoopKit.PumpManagerStatus
    ) {
        guard let pumpManager = pumpManager as? MedtrumPumpManager else {
            return
        }

        DispatchQueue.main.async {
            self.isConnected = pumpManager.bluetooth.isConnected
            self.updateState(pumpManager.state)
        }
    }

    private func updateState(_ state: MedtrumPumpState) {
        model = state.model
        switch model {
        case "MD8301":
            is300u = true
            maxReservoirLevel = 300
        default:
            is300u = false
            maxReservoirLevel = 200
        }

        showPumpTimeSyncWarning = state.shouldShowTimeWarning()
        patchState = state.pumpState
        useSilentTones = state.useSilentTones
        patchStateString = state.pumpState.description
        pumpTime = state.pumpTime
        pumpTimeSyncedAt = state.pumpTimeSyncedAt
        reservoirLevel = patchState != .reservoirEmpty ? state.reservoir : 0
        basalType = state.basalDose.type
        basalRate = basalRateFormatter
            .string(from: (basalType == .tempBasal ? state.basalDose.value : state.currentBaseBasalRate) as NSNumber) ?? ""
        tempBasalManual = state.basalDose.type == .tempBasal && !state.basalDose.automatic
        lastSync = state.lastSync
        patchActivatedAt = state.patchActivatedAt
        patchGracePeriodFrom = state.patchGracePeriodFrom
        patchExpiresAt = state.patchExpiresAt
        if let patchActivatedAt = state.patchActivatedAt {
            patchLifetime = processPatchLifetime(patchActivatedAt, Date())
        }
        hasPreviousPatch = state.previousPatch != nil
        hourlyLimit = Int(state.maxHourlyInsulin)
        dailyLimit = Int(state.maxDailyInsulin)

        if !state.patchId.isEmpty, let patchActivatedAt, let patchGracePeriodFrom {
            let totalLifetime = patchGracePeriodFrom.timeIntervalSince(patchActivatedAt)
            let progress = Date.now.timeIntervalSince1970 - patchActivatedAt.timeIntervalSince1970

            patchLifecycleProgress = min(progress / totalLifetime, 1)
            patchLifecycleState = getLifecycleState(state: state)

            if patchLifecycleState == .gracePeriod, let patchExpiresAt {
                let timeRemaining = patchExpiresAt.timeIntervalSinceNow
                patchGraceTimeout = timeRemainingFormatter.string(from: timeRemaining) ?? ""
            }
        } else {
            patchLifecycleState = .noPatch
        }

        if let insulinType = state.insulinType {
            self.insulinType = insulinType
        }
    }

    private func getLifecycleState(state: MedtrumPumpState) -> PatchLifecycleState {
        if patchLifecycleProgress < 1 {
            if let patchGracePeriodFrom = state.patchGracePeriodFrom,
               patchGracePeriodFrom.addingTimeInterval(.days(-1)) <= Date.now
            {
                return .activeLast24h
            } else {
                return .active
            }
        }

        if let patchExpiresAt, Date.now > patchExpiresAt {
            return state.expiryMode == .extended ? .expiredBasalOnly : .expired
        }

        return .gracePeriod
    }
}
