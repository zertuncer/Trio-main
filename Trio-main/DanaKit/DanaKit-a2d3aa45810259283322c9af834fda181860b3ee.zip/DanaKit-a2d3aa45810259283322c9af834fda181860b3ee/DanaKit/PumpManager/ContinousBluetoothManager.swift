import BackgroundTasks
import CoreBluetooth
import Foundation
import UserNotifications

class ContinousBluetoothManager: NSObject, BluetoothManager {
    var pumpManager: DanaKitPumpManager? {
        didSet {
            autoConnectUUID = pumpManager?.state.bleIdentifier
        }
    }

    // The properties below are touched from the bluetooth queue, the main queue and the thread
    // issuing a command. Hence the locks
    @Locked var autoConnectUUID: String?
    @Locked var connectionCompletion: ((ConnectionResult) -> Void)?
    @Locked var devices: [DanaPumpScan] = []

    let log = DanaLogger(category: "ContinousBluetoothManager")
    var manager: CBCentralManager!
    let managerQueue = DispatchQueue(label: "com.DanaKit.bluetoothManagerQueue", qos: .unspecified)

    @Locked var peripheral: CBPeripheral?
    @Locked var peripheralManager: PeripheralManager?
    @Locked var forcedDisconnect = false

    public var isConnected: Bool {
        self.manager.state == .poweredOn && self.peripheral?.state == .connected && self.pumpManager?.state
            .isConnected ?? false
    }

    override init() {
        super.init()

        managerQueue.sync {
            self.manager = CBCentralManager(delegate: self, queue: managerQueue)
        }
    }

    deinit {
        self.manager = nil
    }

    private func handleBackgroundTask() {
        Task {
            while isConnected {
                keepConnectionAlive()
                try await Task.sleep(nanoseconds: 60_000_000_000) // 60 seconds
            }

            self.log.warning("Existed background job. Not connected anymore")
        }
    }

    private func keepConnectionAlive() {
        do {
            if pumpManager?.status.bolusState == .noBolus {
                log.info("Sending keep alive message")
                let keepAlivePacket = generatePacketGeneralKeepConnection()
                let result = try writeMessage(keepAlivePacket)
                guard result.success else {
                    log.error("Pump rejected keepAlive request: \(result.rawData.base64EncodedString())")
                    return
                }
            } else {
                log.info("Skip sending keep alive message. Reason: bolus is running")
            }
        } catch {
            log.error("Failed to keep connection alive: \(error.localizedDescription)")
        }
    }

    func writeMessage(_ packet: DanaGeneratePacket) throws -> (any DanaParsePacketProtocol) {
        guard let peripheralManager = self.peripheralManager, isConnected else {
            throw NSError(domain: "No connected device", code: 0, userInfo: nil)
        }

        return try peripheralManager.writeMessage(packet)
    }

    public func reconnect(_ callback: @escaping (Bool) -> Void) {
        guard !isConnected else {
            callback(true)
            return
        }

        NotificationHelper.setDisconnectWarning()
        if autoConnectUUID == nil {
            autoConnectUUID = pumpManager?.state.bleIdentifier
        }

        if let peripheral = peripheral {
            connect(peripheral) { result in
                switch result {
                case .success:
                    self.forcedDisconnect = false
                    self.updateInitialState()
                    self.handleBackgroundTask()
                    callback(true)

                default:
                    self.log.error("Failed to reconnect: \(result)")
                    callback(false)
                }
            }
            return
        }

        guard let autoConnect = autoConnectUUID else {
            log.error("No autoConnect: \(String(describing: autoConnectUUID))")
            callback(false)
            return
        }

        do {
            try connect(autoConnect) { result in
                switch result {
                case .success:
                    self.forcedDisconnect = false
                    self.updateInitialState()
                    self.handleBackgroundTask()
                    callback(true)

                default:
                    self.log.error("Failed to do auto connection: \(result)")
                    callback(false)
                }
            }
        } catch {
            log.error("Failed to auto connect: \(error.localizedDescription)")
            callback(false)
        }
    }

    func ensureConnected(_ completion: @escaping (ConnectionResult) -> Void, _: String = #function) {
        if isConnected {
            resetConnectionCompletion()
            pumpManager?.logDeviceCommunication("Dana - Connection is ok!", type: .connection)
            updateInitialState()
            completion(.success)

        } else if !forcedDisconnect {
            reconnect { result in
                guard result else {
                    self.log.error("Failed to reconnect")
                    self.pumpManager?.logDeviceCommunication("Dana - Couldn't reconnect", type: .connection)

                    self.resetConnectionCompletion()
                    completion(.failure(NSError(domain: "Couldn't reconnect", code: -1)))
                    return
                }

                self.resetConnectionCompletion()
                self.pumpManager?.logDeviceCommunication("Dana - Reconnected!", type: .connection)
                self.updateInitialState()
                completion(.success)
            }
        } else {
            // We aren't connected, the user has disconnected the pump by hand
            log.warning("Device is forced disconnected...")
            pumpManager?.logDeviceCommunication(
                "Dana - Pump is not connected. Please reconnect to pump before doing any operations",
                type: .connection
            )

            resetConnectionCompletion()
            completion(.failure(NSError(domain: "Device is forced disconnected...", code: -1)))
        }
    }

    func disconnect(_ peripheral: CBPeripheral, force: Bool) {
        guard force else {
            return
        }

        autoConnectUUID = nil
        forcedDisconnect = true

        pumpManager?.logDeviceCommunication("Dana - Disconnected", type: .connection)
        manager.cancelPeripheralConnection(peripheral)
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        bleCentralManagerDidUpdateState(central)

        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            if central.state == .poweredOn {
                self.reconnect { result in
                    guard result else {
                        return
                    }

                    self.log.info("Reconnected and sync pump data!")
                    self.pumpManager?.syncPump { _ in }
                }
            }
        }
    }

    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        bleCentralManager(central, didDiscover: peripheral, advertisementData: advertisementData, rssi: RSSI)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        bleCentralManager(central, didConnect: peripheral)

        NotificationHelper.clearDisconnectWarning()
        NotificationHelper.clearDisconnectReminder()
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        bleCentralManager(central, didDisconnectPeripheral: peripheral, error: error)

        guard !forcedDisconnect else {
            // Dont reconnect if the user has manually disconnected
            return
        }

        reconnect { result in
            guard result else {
                return
            }

            self.log.info("Reconnected and sync pump data!")
            self.pumpManager?.syncPump { _ in }
        }
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        bleCentralManager(central, didFailToConnect: peripheral, error: error)
    }
}
